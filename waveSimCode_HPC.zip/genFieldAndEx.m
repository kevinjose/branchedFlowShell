function []= genFieldAndEx(hStd, circ, Lz, lam, Lc)
    Nloop = 80;
    E = 200e9;
    H0 = 1e-3;
    kz = 2*pi/lam;
    R = circ/(2*pi);
    dz = lam/8;
    dth = 3*dz/R;
    
    z = 0:dz:Lz;
    th = 0:dth:(2*pi-dth);

    rho = 7800;
    nu = 0.3;

    D = E*H0^3/(12*(1-nu^2));
    Cg = 2*kz*sqrt(D/(rho*H0));
    f = 1/(2*pi)*kz^2*sqrt(D/(rho*H0));

    Tper = 1/f;
    dt = 1/f/8;
    Ttot = 1.15*Lz/Cg;

    if 10*Tper > Ttot
        error('Tube too short')
    end

    t = [linspace(0, 10*Tper, 201), Ttot/2, Ttot];
    zInp = sin(2*pi*f*t).*gaussmf(t, [Tper, 3*Tper]);
    writematrix([t', zInp'], 'AuxFiles/zInp.csv')

    for i = 1:Nloop
        count=0;
        flag = 0;
        while(flag==0)
            h = randFieldGen(hStd, z, th*R, Lc);
            count=count+1;
            if any(H0*(1-h') <0, 'all')
                flag=0;
                disp(count)
            else
                flag=1;
            end
        end
        fieldPadded = [ 0           z;
                        th'*180/pi  H0*(1-h)];

        writematrix(fieldPadded, ['Fields/field', num2str(i), '.csv'])
    end

    fID = fopen('AuxFiles/params.ans', 'w');
    fprintf(fID, 'Eyo = %5.5e\n', E);
    fprintf(fID, 'rho = %5.5e\n', rho);
    fprintf(fID, 'nu = %5.5e\n', nu);
    fprintf(fID, 'Ttot = %8.8e\n', Ttot);
    fprintf(fID, 'dt = %8.8e\n', dt);
    fprintf(fID, 'Lz = %5.5e\n', Lz);
    fprintf(fID, 'R = %5.5e\n', R);
    fprintf(fID, 'dz = %8.8e\n', dz);
    fprintf(fID, 'dth = %8.8e\n', dth);
    fprintf(fID, 'subSteps= %d\n', floor(Ttot/dt));
    fprintf(fID, 'hStd= %d\n', hStd);
    fprintf(fID, 'hStdFld= %d\n', std(h(:)));
    fprintf(fID, 'lam = %5.5e\n', lam);
    fprintf(fID, 'Lc = %5.5e\n', Lc);
    fprintf(fID, 'Nz = %d\n', length(z));
    fprintf(fID, 'Nth = %d\n', length(th));
    fclose(fID);
end
