import pyansys
import numpy as np
from loopNo import i
result = pyansys.read_binary('tempFiles.rst')
t = result.time_values
dt = t[1]-t[0]
disp = np.square(result.nodal_displacement(0)[1][:, 0])*dt +np.square(result.nodal_displacement(0)[1][:, 1])*dt
for sStep in range(1, len(t)):
    disp += np.square(result.nodal_displacement(sStep)[1][:, 0])*dt +np.square(result.nodal_displacement(sStep)[1][:, 1])*dt
np.savetxt('../DataFiles/integIntensity{}.csv'.format(i), disp)