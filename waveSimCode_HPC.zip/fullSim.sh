#!/bin/bash
mkdir AuxFiles
mkdir DataFiles
mkdir Fields
module load matlab/2020a

matlab -nodisplay -nosplash -nodesktop -r "genFieldAndEx(hStd, circ, Lz, lam, Lc); exit;"

for i in {1..4}
        do
        cd set$i
        sbatch run_branch_loop$i.sh
        sleep 0.3
        cd ..
        sleep 0.3
done
