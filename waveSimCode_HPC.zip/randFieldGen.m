function [h, TH_L, Z] = randFieldGen(hStd, z, th_l, Lc)

th_l = th_l-mean(th_l);
z = z-mean(z);
[Z, TH_L] = meshgrid(z, th_l);
randFld = randn(size(TH_L));
F = exp(-((TH_L.^2+Z.^2)/(Lc^2/2)));

h = ifft2(fft2(randFld).*fft2(F));
h = hStd*h/std(h(:));

end