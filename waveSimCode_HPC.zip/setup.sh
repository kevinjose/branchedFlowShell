#!/bin/bash
lamno=0
hStdVals=(0.2000 0.1370 0.0938 0.0643 0.0440 0.0301 0.0206 0.01410 0.0097 0.0066)

for i in {0..6}
do
mkdir sim$i\_l$lamno
cp ../IR5genShell.zip sim$i\_l$lamno/IR5genShell.zip
cd sim$i\_l$lamno
unzip *
sed -i "s/genFieldAndEx(hStd, circ, Lz, lam, Lc)/genFieldAndEx(${hStdVals[$i]}, 0.6, 4, 0.01, 0.1)/" fullSim.sh
sed -i "s/59:00:00/22:00:00/" set*/run_branch_loop*
cd ..
done

for i in {7..9}
do
mkdir sim$i\_l$lamno
cp ../IR5genShell.zip sim$i\_l$lamno/IR5genShell.zip
cd sim$i\_l$lamno
unzip *
sed -i "s/genFieldAndEx(hStd, circ, Lz, lam, Lc)/genFieldAndEx(${hStdVals[$i]}, 0.6, 8, 0.01, 0.1)/" fullSim.sh
sed -i "s/59:00:00/59:00:00/" set*/run_branch_loop*
cd ..
done

