#!/bin/bash
cp Fields/field1.csv DataFiles/field.csv
cp AuxFiles/params.ans DataFiles/params.ans

zip -r -j ${PWD##*/} DataFiles/*