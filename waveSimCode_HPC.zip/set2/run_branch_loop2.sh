#!/bin/bash
# SLURM job script to run Ansys in parallel on a single node using 4 CPUs
#SBATCH --job-name      ansys_dist
#SBATCH --time          59:00:00          # Wall time
#SBATCH --ntasks=64                        # Number of processes
#SBATCH --nodes=1
#SBATCH --partition=highmem
#SBATCH -L aa_r@ansyslm:4,aa_r_hpc@ansyslm:60 
echo No of tasks: $SLURM_NTASKS
cd $PWD

module load ansys/19.4
module load conda

source activate pyenv

for i in {21..40}
  do 
    echo "i = $i" > loopNo.py
	ansys194 -b -dis -np $SLURM_NTASKS -j tempFiles -i ../runOneLoop.ans -o tempFiles.out 
	python expInt.py
	rm tempFiles*.*
  done