function [lf, caustIdx, caustRay, XK, tspan, caustAngLoc] = raySimPierce_ND(hStd, lam, Lc, Lz, R, nRays, system, termAtCaust, seedVal)
    if nargin == 9
      rng(seedVal);
    end
    
    noCaustYet = true;
    nu = 0.3;
    
    H0 = 1/1000;
    k = 2*pi/lam;
    gamma = 1/(k*R);
    eps = H0*k;
    
    c_0 = 1;
    Ttot = Lz/R/c_0;
    dt = Ttot/2001;
    
    dz = Lc/6;
    dth = 2*pi/100;

    for flag = 1:10
        [hVals, x, th] = genRandFieldShell(Lz*1.05, R, dz, dth, hStd, Lc);
        [X, TH] = meshgrid(x, th);
        if all(hVals(:)<1)
            break
        else
            disp(flag)
            disp('Problem')
        end        
    end

    if flag == 10
        error('er')
    end
    
    hGradX = diff(hVals, 1, 2)/(x(2)-x(1));
    hGradS = [hVals(2, :)-hVals(end, :);
              hVals(3:end, :)-hVals(1:end-2, :);
              hVals(1, :)-hVals(end-1, :);]/(2*R*(th(2)-th(1)));

    % h = griddedInterpolant(X', R*TH', hVals');
    delxh = griddedInterpolant(X(:, 1:end-1)', R*TH(:, 1:end-1)', hGradX');
    delsh = griddedInterpolant(X', R*TH', hGradS');

    tspan = 0:dt:Ttot;
    sIn = linspace(0, 2*pi, nRays+1)';
    sIn = sIn(1:end-1);

    XK = nan*zeros(length(sIn), 4, length(tspan));
    XK(:, :, 1) = [0*sIn, sIn, 0*sIn+1, 0*sIn];

    for i=2:length(tspan)
        XK(:, 2, i-1) = wrapTo2Pi(XK(:, 2, i-1));
        p = XK(:, 3, i-1);
        q = XK(:, 4, i-1);
        
        if any(XK(:, 1, i-1)*R> Lz)
            break
        end
        
        switch system
            case 'full'
                h_xtilde = delxh(XK(:, 1, i-1)*R, XK(:, 2, i-1)*R)*R;
                h_stilde = delsh(XK(:, 1, i-1)*R, XK(:, 2, i-1)*R)*R;
                XKdot = [p.^3+q.^2.*p.*(1-(12*gamma^2*(nu^2-1)*p.^2)./(eps^2*(p.^2+q.^2).^3)),...
                        (q.*(eps^2.*q.^8+4*eps^2.*q.^6.*p.^2+6*(2*gamma^2*(-1+nu^2)+eps^2*q.^4).*p.^4+4*eps^2.*q.^2.*p.^6+eps^2*p.^8))./(eps^2*(q.^2+p.^2).^3),...
                        1/2*(p.^2+q.^2).^2.*h_xtilde,...
                        1/2*(p.^2+q.^2).^2.*h_stilde];
                
            case 'paraxial'
                h_stilde = delsh(XK(:, 1, i-1)*R, XK(:, 2, i-1)*R)*R;
                XKdot = [1+0*p,...
                        q*(12*gamma^2*(nu^2-1)/eps^2+1),...
                        0*p,...
                        h_stilde*1/2];
        end

        XK(:, :, i) = XK(:, :, i-1) +XKdot*dt;
        
        if noCaustYet
            s = XK([1:end, 1], 2, i);
            var_s = diff(s);
            var_s(var_s>pi) = var_s(var_s>pi) -2*pi;
            var_s(var_s<-pi) = var_s(var_s<-pi) +2*pi;
            
            ks = XK([1:end, 1], 4, i);
            var_ks = diff(ks);
            
            angVals = atan2(var_ks, var_s);
            if sum(abs(angVals)>pi/2)>2
%             if any(abs(angVals)>pi/2)
                noCaustYet = false;
                caustIdx = i;
                caustRay = find(abs(angVals)>pi/2, 1);
                lf = XK(caustRay, 1, caustIdx);
                caustAngLoc = XK(caustRay, 2, caustIdx);
                
                if termAtCaust
                    return
                end
            end
        end
    end
    
    if noCaustYet
        lf = nan;
        caustIdx = i;
        caustRay = nan;
        caustAngLoc = nan;
    end
end