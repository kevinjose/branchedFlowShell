function [lf, caustIdx, caustRay, XK, tspan, caustAngLoc] = raySimYu_ND(hStd, lam, Lc, Lz, R, nRays, system, termAtCaust, seedVal)
    if nargin == 9
      rng(seedVal);
    end
    
    noCaustYet = true;
    nu = 0.3;
    H0 = 1/1000;
    k = 2*pi/lam;
    gamma = 1/(k*R);
    eps = H0*k;
    
    c_0 = -(((-12+eps.^2).*(-6+eps.^2+6.*nu))./(216.*(-1+nu)))+gamma.^2.*(-(1./2)-nu./3+(4-4.*nu.^2)./eps.^2);
    Ttot = Lz/R/c_0;
    dt = Ttot/2001;
    
    dz = Lc/6;
    dth = 2*pi/100;

    for flag = 1:10
        [hVals, x, th] = genRandFieldShell(Lz*1.05, R, dz, dth, hStd, Lc);
        [X, TH] = meshgrid(x, th);
        if all(hVals(:)<1)
            break
        else
            disp(flag)
            disp('Problem')
        end        
    end

    if flag == 10
        error('er')
    end
    
    hGradX = diff(hVals, 1, 2)/(x(2)-x(1));
    hGradS = [hVals(2, :)-hVals(end, :);
              hVals(3:end, :)-hVals(1:end-2, :);
              hVals(1, :)-hVals(end-1, :);]/(2*R*(th(2)-th(1)));

    % h = griddedInterpolant(X', R*TH', hVals');
    delxh = griddedInterpolant(X(:, 1:end-1)', R*TH(:, 1:end-1)', hGradX');
    delsh = griddedInterpolant(X', R*TH', hGradS');

    tspan = 0:dt:Ttot;
    sIn = linspace(0, 2*pi, nRays+1)';
    sIn = sIn(1:end-1);

    XK = nan*zeros(length(sIn), 4, length(tspan));
    XK(:, :, 1) = [0*sIn, sIn, 0*sIn+1, 0*sIn];

    for i=2:length(tspan)
        XK(:, 2, i-1) = wrapTo2Pi(XK(:, 2, i-1));
        p = XK(:, 3, i-1);
        q = XK(:, 4, i-1);
        
        if any(XK(:, 1, i-1)*R> Lz)
            break
        end
        
        switch system
            case 'full'
                h_xtilde = delxh(XK(:, 1, i-1)*R, XK(:, 2, i-1)*R)*R;
                h_stilde = delsh(XK(:, 1, i-1)*R, XK(:, 2, i-1)*R)*R;
                XKdot = [-(1./(216.*eps.^2.*(-1+nu)))*p.*(9.*p.^4.*(eps.^4.*(-3+nu)-48.*q.^2.*eps.^2.*(-1+nu))-144.*p.^6.*eps.^2.*(-1+nu)+p.^2.*(eps.^6+18.*q.^2.*eps.^4.*(-3+nu)+72.*eps.^2.*(-1+nu)-432.*q.^4.*eps.^2.*(-1+nu)+864.*gamma.^2.*(-1+nu).^2.*(1+nu))+eps.^2.*(q.^2.*(eps.^4+72.*(-1+nu))-3.*eps.^2.*(-3+nu)+9.*q.^4.*eps.^2.*(-3+nu)-144.*q.^6.*(-1+nu)+36.*gamma.^2.*(-3+nu+2.*nu.^2))),...
                         -(1./(216.*(-1+nu)))*q.*(-36.*gamma.^2+9.*eps.^2+9.*p.^4.*(eps.^2.*(-3+nu)-48.*q.^2.*(-1+nu))+9.*q.^4.*eps.^2.*(-3+nu)-144.*p.^6.*(-1+nu)-144.*q.^6.*(-1+nu)+36.*gamma.^2.*nu-3.*eps.^2.*nu+q.^2.*(-72+eps.^4+72.*nu)+p.^2.*(-72+eps.^4+18.*q.^2.*eps.^2.*(-3+nu)-432.*q.^4.*(-1+nu)+72.*nu)),...
                         h_xtilde.*(1./(432.*(-1+nu))*(p.^2+q.^2).^2.*(12.*p.^2+12.*q.^2-eps.^2).*(eps.^2+6.*p.^2.*(-1+nu)+6.*q.^2.*(-1+nu))),...
                         h_stilde.*(1./(432.*(-1+nu))*(p.^2+q.^2).^2.*(12.*p.^2+12.*q.^2-eps.^2).*(eps.^2+6.*p.^2.*(-1+nu)+6.*q.^2.*(-1+nu)))];
                
            case 'paraxial'
                h_stilde = delsh(XK(:, 1, i-1)*R, XK(:, 2, i-1)*R)*R;
                XKdot = [c_0+0*p,...
                        q*(1/216*(-36.*gamma.^2-((-12+eps.^2).*(-6+eps.^2+6.*nu))./(-1+nu))),...
                        0*p,...
                        h_stilde*(-(((-12+eps.^2).*(-6+eps.^2+6.*nu))./(432.*(-1+nu))))];
                    
           
        end

        XK(:, :, i) = XK(:, :, i-1) +XKdot*dt;
        
        if noCaustYet
            s = XK([1:end, 1], 2, i);
            var_s = diff(s);
            var_s(var_s>pi) = var_s(var_s>pi) -2*pi;
            var_s(var_s<-pi) = var_s(var_s<-pi) +2*pi;
            
            ks = XK([1:end, 1], 4, i);
            var_ks = diff(ks);
            
            angVals = atan2(var_ks, var_s);
            if sum(abs(angVals)>pi/2)>2
%             if any(abs(angVals)>pi/2)
                noCaustYet = false;
                caustIdx = i;
                caustRay = find(abs(angVals)>pi/2, 1);
                lf = XK(caustRay, 1, caustIdx);
                caustAngLoc = XK(caustRay, 2, caustIdx);
                
                if termAtCaust
                    return
                end
            end
        end
    end
    
    if noCaustYet
        lf = nan;
        caustIdx = i;
        caustRay = nan;
        caustAngLoc = nan;
    end
end